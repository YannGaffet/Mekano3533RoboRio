This directory contains the following files:

navx-mxp.skp:  Sketchup File for the navX MXP Circuit Board
navXLogo.skp:  Sketchup File for the navX MXP Logo
navx-mxp-roborio-lid.skp:  Sketchup File for the navX MXP Roborio Lid-style enclosure (X1000 scale)
navx-mxp-roborio-lid.stl:  STL File for the navX MXP Roborio Lid-style enclosure (actual scale)